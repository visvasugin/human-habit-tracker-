# Human Habit Tracker

A simple, responsive habit tracking website built with **HTML, CSS, and JavaScript**.

## Features

- Add new habits
- Choose a habit category
- Mark habits as completed for today
- Automatic daily progress percentage
- Current streak calculation
- Best streak tracking
- Delete habits
- Clear today's completed checks
- Data saved automatically in browser `localStorage`
- Responsive design for desktop and mobile

## Project Structure

```text
human-habit-tracker/
├── index.html
├── style.css
├── script.js
└── README.md
```

## How to Run

### Option 1 — Open directly

Download the project and double-click `index.html`.

### Option 2 — VS Code

1. Open the project folder in VS Code.
2. Open `index.html`.
3. Use Live Server if installed.

### Option 3 — GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
3. Go to **Settings → Pages**.
4. Select the main branch and root folder.
5. Save.
6. GitHub will provide your live website link.

## Technologies

- HTML5
- CSS3
- JavaScript
- Browser LocalStorage

## Future Improvements

- User login
- Cloud database
- Weekly/monthly calendar
- Habit reminders
- Charts and analytics
- Dark mode
- Mobile app version
