const STORAGE_KEY = "humanHabitTracker";

let habits = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [
  { id: 1, name: "Drink 2L of water", category: "Health", history: [] },
  { id: 2, name: "Read for 20 minutes", category: "Personal", history: [] },
  { id: 3, name: "Exercise", category: "Fitness", history: [] }
];

const todayKey = () => new Date().toISOString().slice(0, 10);

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(habits));
}

function isCompletedToday(habit) {
  return habit.history.includes(todayKey());
}

function calculateStreak(habit) {
  let streak = 0;
  const date = new Date();

  while (true) {
    const key = date.toISOString().slice(0, 10);
    if (!habit.history.includes(key)) break;
    streak++;
    date.setDate(date.getDate() - 1);
  }

  return streak;
}

function bestStreak(habit) {
  if (!habit.history.length) return 0;

  const dates = [...new Set(habit.history)]
    .map(d => new Date(d))
    .sort((a, b) => a - b);

  let best = 1;
  let current = 1;

  for (let i = 1; i < dates.length; i++) {
    const difference = (dates[i] - dates[i - 1]) / 86400000;
    if (difference === 1) {
      current++;
      best = Math.max(best, current);
    } else {
      current = 1;
    }
  }

  return best;
}

function toggleHabit(id) {
  const habit = habits.find(h => h.id === id);
  const today = todayKey();

  if (habit.history.includes(today)) {
    habit.history = habit.history.filter(date => date !== today);
  } else {
    habit.history.push(today);
  }

  save();
  render();
}

function deleteHabit(id) {
  if (!confirm("Delete this habit?")) return;
  habits = habits.filter(h => h.id !== id);
  save();
  render();
}

function render() {
  const list = document.getElementById("habitList");
  const empty = document.getElementById("emptyState");

  list.innerHTML = "";
  empty.style.display = habits.length ? "none" : "block";

  habits.forEach(habit => {
    const done = isCompletedToday(habit);
    const streak = calculateStreak(habit);

    const item = document.createElement("div");
    item.className = `habit ${done ? "done" : ""}`;

    item.innerHTML = `
      <div class="check" onclick="toggleHabit(${habit.id})">${done ? "✓" : ""}</div>
      <div>
        <div class="habit-name">${escapeHTML(habit.name)}</div>
        <div class="habit-category">${escapeHTML(habit.category)}</div>
      </div>
      <div class="streak">🔥 ${streak} day${streak === 1 ? "" : "s"}</div>
      <button class="delete-btn" onclick="deleteHabit(${habit.id})">Delete</button>
    `;

    list.appendChild(item);
  });

  updateStats();
}

function updateStats() {
  const total = habits.length;
  const completed = habits.filter(isCompletedToday).length;
  const progress = total ? Math.round((completed / total) * 100) : 0;
  const best = habits.reduce((max, habit) => Math.max(max, bestStreak(habit)), 0);

  document.getElementById("totalHabits").textContent = total;
  document.getElementById("completedToday").textContent = completed;
  document.getElementById("bestStreak").textContent = best;
  document.getElementById("progressText").textContent = `${progress}%`;
  document.getElementById("progressPercent").textContent = `${progress}%`;
  document.getElementById("progressFill").style.width = `${progress}%`;
}

function escapeHTML(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

document.getElementById("habitForm").addEventListener("submit", event => {
  event.preventDefault();

  const nameInput = document.getElementById("habitName");
  const categoryInput = document.getElementById("habitCategory");
  const name = nameInput.value.trim();

  if (!name) return;

  habits.push({
    id: Date.now(),
    name,
    category: categoryInput.value,
    history: []
  });

  nameInput.value = "";
  save();
  render();
});

document.getElementById("clearCompleted").addEventListener("click", () => {
  habits.forEach(habit => {
    habit.history = habit.history.filter(date => date !== todayKey());
  });
  save();
  render();
});

document.getElementById("today").textContent = new Date().toLocaleDateString(
  undefined,
  { weekday: "long", year: "numeric", month: "long", day: "numeric" }
);

render();
